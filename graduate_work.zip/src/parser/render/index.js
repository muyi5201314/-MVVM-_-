import { render } from "./render.js";

export {
  render
}