const userUrl = {
  login: 'login',
  selectUser: "selectUser",
}

export {
  userUrl
}