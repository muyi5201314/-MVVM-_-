const mountPotint = []

export {
  mountPotint
}