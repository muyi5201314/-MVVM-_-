const  notFound = {
  template: 
  `
  <h1>404</h1>
  `,
  // 这里有可能形成闭环
  components: {
  },
  props: {
  },
  emits: new Set(),
  data() {
    return {
    }
  },
  methods: {
  },
}

export default notFound